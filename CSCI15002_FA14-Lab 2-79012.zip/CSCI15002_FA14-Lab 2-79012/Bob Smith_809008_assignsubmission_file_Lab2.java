import java.util.Scanner;


public class Lab2 
{
	public static void main(String[] args) 
	{
		int a;
		int b;
		String s1;
		String s2;
		
		Scanner in = new Scanner (System.in);
		
		System.out.print("Enter an integer: ");
		a = in.nextInt();
		System.out.print("Enter another integer: ");
		b = in.nextInt();
		
		if (a > b)
			System.out.println(a + " is greater than " + b);
		if (a == b)
			System.out.println(a + " equals " + b);
		else if (a < b)
			System.out.println(a + " is less than " + b);
		
		System.out.println("Enter a string: ");
		s1 = in.next();
		System.out.println("Enter another string: ");
		s2 = in.next();
		
		if (s1.length() < 6)
			System.out.println("string one is short");
		else 
		{
			System.out.println("The third through the fifth character of " + "\"" 
					+ s1 + "\"" + " are " + "\"" + s1.substring(2,5) + "\"");
			System.out.println("The first character is " + "\'" + s1.charAt(0) + "\'");
		}
			
		if (s1.equals(s2))
			System.out.println("String one and string two are the same.");
		else
			System.out.println("String one and string two are not the same.");
		
		
	}
}
