import java.util.Scanner;


public class Lab2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int x;
		int y;
		String s1;
		String s2;
		
		
		
		System.out.print("Please enter an integer: ");
		x=in.nextInt();
		System.out.print("Please enter another integer:");
		y=in.nextInt();
		
		if(x>y)
		{
			System.out.println("The first value is greater than the second.");
			
		}
		else if(x<y)
		{
			System.out.println("The first value is less than the second.");
		}
		else
			System.out.println("The two values are equal.");
		
		System.out.print("Please enter a Strings: ");
		s1=in.next();
		
		System.out.print("Please enter another String: ");
		s2=in.next();

		if(s1.length()<5)
		{
			System.out.println("s1 is a short string.");
		}
		else 
		{
			String s3=s1.substring(0,1);
			String s4=s1.substring(2,5);
			System.out.println("The first char is "+s3+" The char 3-5 are "+s4);
		}
			
		if(s1.equals(s2))
		{
			System.out.println("Strings are the same.");
		}
		else 
			System.out.println("S1 and S2 are not the same.");
	
		

	}

}
