package lab2;

import java.util.Scanner;

public class Lab2  
{
	public static void main (String [] args)
	{
		Scanner in = new Scanner (System.in);
		
		System.out.print("Enter an integer: ");
		int number1 = in.nextInt();
		
		
		System.out.print("Enter another integer: ");
		int number2 = in.nextInt();
		
		if(number1 > number2)
		{
			System.out.println(number2 + " is less than " + number1);
			
		}
		else
		{
			System.out.println(number1 + " is less than " + number2);
		}
		
		
		
		System.out.print("Enter a String Value:");
		String s1 = "";
		s1 = in.next( );
		
		
		System.out.print("Enter another String value: ");
		String s2 = "";
		s2 = in.next( );
		
		if(s1.length() <= 5)
		{
			System.out.println(s1 + " is a short string");
		
		
		 	if (s1.equals(s2))
		 		{
		 			System.out.print("s1 and s2 are the same");
		 		}
		 	else
		 		{
		 			System.out.println("s1 and s2 are not the same");
		 		}
		 
		}
		else
		{
			String str = s1;
			String res = str.substring(2,5);
			
			System.out.println("The third through fifth characters of " +s1+ " are '" + res+ "'");
			
			String str2 = s1;
			String res2 = str.substring(0,1);
			System.out.println("The first charcater is '" + res2 +"'");
			
			if(s1.equals(s2))
			{
				System.out.println("s1 and s2 are the same.");
			}
			else 
			{
				System.out.println("s1 and s2 are not the same.");
			}
		}
		
		}
	
}
